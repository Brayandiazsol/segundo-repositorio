import java.util.Scanner;

public class estaciones {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("ingrese el numero del mes (1-12): ");
        int mes = scanner.nextInt();
        switch (mes) {
            case 1:
            case 2:
            case 3:
                System.out.println("la estacion es invierno.");
                break;
            case 4:
            case 5:
            case 6:
                System.out.println("la estacion es primavera.");
                break;
            case 7:
            case 8:
            case 9:
                System.out.println("la estacion es verano.");
                break;
            case 10:
            case 11:
            case 12:
                System.out.println("la estacion es otoño.");
                break;
            default:
                System.out.println("el número del mes es invalido.");
                break;
        }
        scanner.close();
    }
}