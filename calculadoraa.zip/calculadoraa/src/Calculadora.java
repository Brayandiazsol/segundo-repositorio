import java.util.Scanner;

public class Calculadora {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el primer número: ");
        float numeroUno = scanner.nextFloat();

        System.out.print("Ingrese el signo (+, -, *, /): ");
        String signo = scanner.next();

        System.out.print("Ingrese el segundo número: ");
        float numeroDos = scanner.nextFloat();

        float resultado = 0;
        boolean operacionValida = true;

        switch (signo) {
            case "+":
                resultado = numeroUno + numeroDos;
                break;
            case "-":
                resultado = numeroUno - numeroDos;
                break;
            case "*":
                resultado = numeroUno * numeroDos;
                break;
            case "/":
                if (numeroDos != 0) {
                    resultado = numeroUno / numeroDos;
                } else {
                    System.out.println("No se puede dividir entre 0.");
                    operacionValida = false;
                }
                break;
            default:
                System.out.println("La operación es inválida.");
                operacionValida = false;
                break;
        }
        if (operacionValida) {
            System.out.println("El resultado es: " + resultado);
        }

        scanner.close();
    }
}